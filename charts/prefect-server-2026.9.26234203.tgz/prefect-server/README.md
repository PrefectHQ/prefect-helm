# prefect-server

Prefect server application bundle

**Homepage:** <https://github.com/PrefectHQ>

## Installing the Chart

To install the chart with the release name `prefect-server`:

```console
helm repo add prefect https://prefecthq.github.io/prefect-helm
helm install prefect-server prefect/prefect-server
```

## Prefect Configuration

### Container Port // Port Forwarding

Without making any modifications to the `values.yaml` file, you can access the Prefect UI by port forwarding either the Server `pod` or `service` with the following command and visiting [http:localhost:4200](http:localhost:4200):
```console
kubectl port-forward svc/prefect-server 4200:4200
```

Note: If you choose to make modifications to either the `server.prefectApiUrl` or `service.port`, make sure to update the other value with the updated port!

### Basic Auth

Prefect documentation on [basic auth](https://docs.prefect.io/v3/develop/settings-and-profiles#security-settings)

Self-hosted Prefect servers can be equipped with a Basic Authentication string for an administrator/password combination.

The format of the auth string is `admin:<my-password>` (no brackets).

```yaml
server:
  basicAuth:
    enabled: true
    authString: "admin:pass"
```

Alternatively, you can provide an existing Kubernetes Secret containing the auth string credentials. The secret must contain a key `auth-string` with the value of the auth string.

```sh
kubectl create secret generic prefect-basic-auth --from-literal=auth-string='admin:my-password'
```

```yaml
server:
  basicAuth:
    enabled: true
    existingSecret: prefect-basic-auth
```

### Container seccomp profile

The chart passes `server.containerSecurityContext` to the server container.
Set `seccompProfile` there when a policy requires a profile on the container.
For a `Localhost` profile, set `localhostProfile` to a path relative to the kubelet's seccomp profile directory.

```yaml
server:
  containerSecurityContext:
    seccompProfile:
      type: Localhost
      localhostProfile: profiles/restricted.json
```

### Health Probes

The server enables startup, liveness, and readiness probes by default. Their default paths follow `server.apiBasePath`. The startup and liveness probes call `/health`, which confirms that the HTTP server responds. The readiness probe calls `/ready`, which confirms that Prefect can connect to its database. These endpoints do not check Redis connectivity.

The startup probe allows the server up to five minutes to become healthy with the default settings. Kubernetes waits for it to succeed before running the liveness and readiness probes. You can tune each probe under its `config` key or disable it through `enabled`.

You can also override `server.livenessProbe.path` or `server.readinessProbe.path`. For example, point the liveness probe at `/api/ready` if sustained database connectivity failures should restart the server pod instead of only removing it from service:

```yaml
server:
  startupProbe:
    enabled: false
  livenessProbe:
    path: "/api/ready"
  readinessProbe:
    enabled: false
```

## Background Services Configuration

The Prefect server includes background services related to scheduling and
cleanup. By default, these run in the same deployment as the web server, but
they can be separated for better resource management and scalability.

Support for this separation was added to provide a path to scaling your deployment as your usage grows.
If you are orchestrating a lot of work, you may need more web services to handle requests than background
services to field the increased API requests.

By default, the web services and background services share a connection pool to the
database, but their connection needs are very different and even antagonistic
with each other at times. Splitting the background services out also allows you
to tune the database connections for each deployment (pool size, timeout, etc.),
which can help with the database load.

The separate deployment for background services is currently limited to one replica
because it has not been optimized for running multiple copies. Additionally, many background
services run on a loop between 5 and 60 seconds, so if they go down, Kubernetes should bring
them back up after a health check without much disruption.

Splitting the background services is optional, and is likely not necessary if
you are not having any issues with your setup.

To run background services in a separate deployment:

> [!WARNING]
> **Version Requirement**: When using `backgroundServices.runAsSeparateDeployment: true`, you must use Prefect 3.4.16 or later. Earlier versions have a bug where the `--no-services` flag doesn't fully disable background services, causing Redis connection errors in the server pod.

```yaml
backgroundServices:
  runAsSeparateDeployment: true

# Use the bundled Redis chart
# See the next section for more details on other deployment options
redis:
  enabled: true
```

This configuration is recommended when:
- You're experiencing database connection pool contention
- You need different scaling policies for the web server and background services
- You want to monitor and manage resource usage separately

You can read more about this architecture in the [How to scale self-hosted Prefect](https://docs.prefect.io/v3/advanced/self-hosted) guide.

## Redis Configuration

This section applies when enabling the use of Background Services.

For a simple deployment, you can use the bundled Redis chart by setting the following:

```yaml
redis:
  enabled: true
```

This will automatically configure the Prefect server and background services to use the bundled Redis instance with the correct connection string information.

If you want to use the bundled Redis chart but need to customize the configuration, you can do so by providing additional values under the `redis` section. For example:

```yaml
redis:
  enabled: true

  auth:
    # set a custom password for the Redis instance
    password: "dontpanic!"
```

You can find additional configuration values in the [Bitnami Redis chart values.yaml file](https://github.com/bitnami/charts/blob/main/bitnami/redis/values.yaml).

**NOTE** Using the embedded Bitnami Redis chart his is **not intended for production use**, and is only
included to provide a functional proof of concept installation.

### Using an External Redis Instance

If you want to use an existing or external Redis instance, do not set `redis.enabled`. Provide the connection details in the `backgroundServices.messaging.redis` section:

```yaml
backgroundServices:
  runAsSeparateDeployment: true
  messaging:
    redis:
      host: external.redis.host.example.com
      username: marvin
      password: paranoid!
```

If you want to reference an existing Kubernetes Secret for the Redis password instead of providing it in plain text, use the `existingSecret` field:

```yaml
backgroundServices:
  runAsSeparateDeployment: true
  messaging:
    redis:
      host: external.redis.host.example.com
      username: marvin
      existingSecret: my-redis-secret
      existingSecretPasswordKey: redis-password  # default key name
```

The `existingSecretPasswordKey` field defaults to `redis-password` to match the Bitnami Redis chart convention. Set it to a different value if your secret uses a different key.

## PostgreSQL Configuration

### Handling Connection Secrets

#### Using the bundled PostgreSQL chart

By default, Bitnami's PostgreSQL Helm Chart will be deployed. This is **not intended for production use**, and is only
included to provide a functional proof of concept installation.

In this scenario, you'll need to provide _either one_ of the following fields:

1. `postgresql.auth.password`: a password you want to set for the prefect user (default: `prefect-rocks`)

2. `postgresql.auth.existingSecret`: name of an existing secret in your cluster with the following field:

    - `connection-string`: fully-quallified connection string in the format of `postgresql+asyncpg://{username}:{password}@{hostname}/{database}`
        - username = `postgresql.auth.username`
        - hostname = `<release-name>-postgresql.<release-namespace>:<postgresql.containerPorts.postgresql>`
        - database = `postgresql.auth.database`

Two secrets are created when not providing an existing secret name:
1. `prefect-server-postgresql-connection`: used by the prefect-server deployment to connect to the postgresql database.

2. `<release-name>-postgresql-0`: defines the `postgresql.auth.username`'s password on the postgresql server to allow successful authentication from the prefect server.

#### Using an external instance of PostgreSQL

If you want to disable the bundled PostgreSQL chart and use an external instance, use the `externalDatabase` block. It is only for external databases; for databases managed by this chart, continue to configure the bundled PostgreSQL chart with `postgresql` or the embedded SQLite database with `sqlite`.

Database connection configuration is applied in this order:

1. `sqlite.enabled=true` uses the embedded SQLite database.
2. `externalDatabase.connectionString` uses a literal external database connection URL.
3. `externalDatabase.existingSecret` with `externalDatabase.connectionStringSecretKey` reads a full external database connection URL from an existing Secret.
4. `externalDatabase` component fields and Secret keys compose an external database connection URL from driver, username, password, host, port, and name.
5. Existing `secret`/`postgresql` behavior is used when none of the above `externalDatabase` options are set.

```yaml
postgresql:
  enabled: false

secret:
  # Option 1: provide the name of an existing secret following the instructions above.
  create: false
  name: <existing secret name>

  # Option 2: provide the connection string details directly
  create: true
  username: myuser
  password: mypass
  host: myhost.com
  port: 1234
  database: mydb
```

If your external database credentials are split across Secret keys and values, use the `externalDatabase` block instead. This is useful for operators that create immutable credential Secrets, such as the Zalando Postgres Operator.

```yaml
postgresql:
  enabled: false

externalDatabase:
  existingSecret: user.clustername.credentials.postgresql.acid.zalan.do
  driver: postgresql+asyncpg
  usernameSecretKey: username
  passwordSecretKey: password
  host: postgres.internal.svc.cluster.local
  port: "5432"
  name: prefect
```

When `externalDatabase.connectionString` or `externalDatabase.connectionStringSecretKey` is set, that full connection string takes precedence over the component settings.

### Connecting with SSL configured

1. Mount the relevant certificate to `/home/prefect/.postgresql` so that it can be found by `asyncpg`. This is the default location postgresql expects per their [documentation](https://www.postgresql.org/docs/current/libpq-ssl.html).
    ```yaml
    server:
      extraVolumes:
        - name: db-ssl-secret
          secret:
            secretName: db-ssl-secret
            defaultMode: 384
      extraVolumeMounts:
        - name: db-ssl-secret
          mountPath: "/home/prefect/.postgresql"
          readOnly: true
    postgresql:
      enabled: false
      auth:
        existingSecret: external-db-connection-string
    ```

2. Create a secret to hold the ca certificate for the database with the key `root.crt`
    ```yaml
    apiVersion: v1
    kind: Secret
    metadata:
      name: db-ssl-secret
    data:
      root.crt: BASE64ENCODECERTIFICATE=
    type: Opaque
    ```

3. Set the connection string in the existing secret following this format - `?ssl=verify-ca` is crucial:
    ```
    postgresql+asyncpg://{username}:{password}@{hostname}/{database}?ssl=verify-ca
    ```

### Database Migrations

Database migrations are handled differently depending on your deployment mode.

**Single deployment (default):** Prefect automatically runs database migrations on server startup. No additional configuration is needed because there is only one server process managing the database.

**Separate deployment mode (`backgroundServices.runAsSeparateDeployment: true`):** The chart creates a dedicated Kubernetes Job as a Helm pre-upgrade/post-install hook to run migrations before the deployments start. This prevents multiple server processes (API server and background services) from racing to migrate the database simultaneously. Both deployments set `PREFECT_SERVER_DATABASE_MIGRATE_ON_START=false` so that only the Job handles migrations.

The migration Job will:

1. Run `prefect server database upgrade -y` before updating the main deployments
2. Ensure your database schema is compatible with the new Prefect version
3. Block the upgrade if migrations fail

**Important Notes:**
- Migrations only run for PostgreSQL deployments (not SQLite)
- The migration job uses the same database credentials as your main deployment
- **Downgrades require manual intervention** - if you need to rollback, you may need to manually run database downgrade commands
- For more details, see [Prefect's database migration documentation](https://docs.prefect.io/v3/advanced/self-hosted#database-migrations)

#### Migration Configuration

The `migrations` section in your values configures the migration Job. These settings only take effect when `backgroundServices.runAsSeparateDeployment` is `true`.

For example, to disable the migration Job (not recommended):

```yaml
migrations:
  # Enable/disable the migration Job (default: true)
  enabled: false
```

Consult the `values.yaml` file for additional configuration options such as resource requests/limits, backoff limits, and timeouts.

## SQLite Configuration

SQLite can be used as an alternative to PostgreSQL. As mentioned in the
[documentation on hosting Prefect](https://docs-3.prefect.io/v3/manage/self-host),
SQLite is only recommended for lightweight, single-server deployments.

To use SQLite for the database, provide the following configuration values:

```yaml
postgresql:
  enabled: false
sqlite:
  enabled: true
```

More configuration options are available in [`values.yaml`](./values.yaml).

By default, a PersistentVolumeClaim persists the SQLite database file between
Pod restarts.

Note that enabling SQLite enforces 1 replica in the Deployment, and disables
the HorizontalPodAutoscaler.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| jamiezieziula | <jamie@prefect.io> |  |
| jimid27 | <jimi@prefect.io> |  |
| parkedwards | <edward@prefect.io> |  |
| mitchnielsen | <mitchell@prefect.io> |  |

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://charts.bitnami.com/bitnami | common | 2.41.0 |
| https://charts.bitnami.com/bitnami | postgresql | 12.12.10 |
| https://charts.bitnami.com/bitnami | redis | 28.1.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| backgroundServices.affinity | object | `{}` | affinity for background-services pod assignment |
| backgroundServices.args | list | `[]` | Custom container command arguments |
| backgroundServices.automountServiceAccountToken | bool | `true` | whether the background services pod mounts a service account API token. background services do not call the kubernetes api, so this can be set to false |
| backgroundServices.command | list | `[]` | Custom container entrypoint |
| backgroundServices.containerSecurityContext.allowPrivilegeEscalation | bool | `false` | set background-services containers' security context allowPrivilegeEscalation |
| backgroundServices.containerSecurityContext.capabilities | object | `{}` | set background-services container's security context capabilities |
| backgroundServices.containerSecurityContext.readOnlyRootFilesystem | bool | `true` | set background-services containers' security context readOnlyRootFilesystem |
| backgroundServices.containerSecurityContext.runAsNonRoot | bool | `true` | set background-services containers' security context runAsNonRoot |
| backgroundServices.containerSecurityContext.runAsUser | int | `1001` | set background-services containers' security context runAsUser |
| backgroundServices.debug | bool | `false` | sets PREFECT_DEBUG_MODE |
| backgroundServices.env | list | `[]` | array with environment variables to add to background-services container |
| backgroundServices.extraContainers | list | `[]` | additional sidecar containers |
| backgroundServices.extraEnvVarsCM | string | `""` | name of existing ConfigMap containing extra env vars to add to background-services pod |
| backgroundServices.extraEnvVarsSecret | string | `""` | name of existing Secret containing extra env vars to add to background-services pod |
| backgroundServices.extraInitContainers | list | `[]` | additional init containers for the background-services pod. Set `restartPolicy: Always` on an entry to use the native sidecar pattern (Kubernetes 1.29+), which guarantees the sidecar starts before, and is terminated after, the main container — useful for connection proxies (e.g. redis-iam-proxy, cloud-sql-proxy) so background services can drain their connections cleanly during shutdown. |
| backgroundServices.extraVolumeMounts | list | `[]` | array with extra volumeMounts for the background-services pod |
| backgroundServices.extraVolumes | list | `[]` | array with extra volumes for the background-services pod |
| backgroundServices.lifecycle | object | `{}` | lifecycle hooks for the background-services container. Useful for adding a `preStop` hook that gives the worker time to wind down before SIGTERM. |
| backgroundServices.loggingLevel | string | `"WARNING"` | sets PREFECT_LOGGING_SERVER_LEVEL |
| backgroundServices.messaging.broker | string | `"prefect_redis.messaging"` | messaging broker class to use for background services |
| backgroundServices.messaging.cache | string | `"prefect_redis.messaging"` | messaging cache class to use for background services |
| backgroundServices.messaging.docket.existingSecret | string | `""` | name of an existing Kubernetes secret containing the Docket URL. Takes precedence over the url field above. The secret should contain a key with the full Redis URL including any credentials. |
| backgroundServices.messaging.docket.existingSecretKey | string | `"docket-url"` | key within the existing secret that contains the Docket URL |
| backgroundServices.messaging.docket.url | string | `""` | URL for the Docket scheduler backend. Examples: redis://host:6379/0, redis://host:6379/0 (TLS), redis://user:pass@host:6379/0. Leave empty to use the default in-memory backend (memory://). |
| backgroundServices.messaging.redis | object | `{"db":0,"existingSecret":"","existingSecretPasswordKey":"redis-password","host":"","password":"","port":6379,"ssl":false,"username":""}` | settings for redis broker/cache change these if not using the built-in redis subchart |
| backgroundServices.messaging.redis.db | int | `0` | redis database number |
| backgroundServices.messaging.redis.existingSecret | string | `""` | name of an existing Kubernetes secret containing the redis password takes precedence over the password field above |
| backgroundServices.messaging.redis.existingSecretPasswordKey | string | `"redis-password"` | key within the existing secret that contains the redis password |
| backgroundServices.messaging.redis.host | string | `""` | redis hostname if using the built-in redis subchart, this will be automatically set to the redis subchart's service name |
| backgroundServices.messaging.redis.password | string | `""` | redis password, leave empty to use default if using the built-in redis subchart, this will be automatically set to the redis subchart's password value |
| backgroundServices.messaging.redis.port | int | `6379` | redis port |
| backgroundServices.messaging.redis.ssl | bool | `false` | use TLS for redis connection |
| backgroundServices.messaging.redis.username | string | `""` | redis username, leave empty to use no authentication if using the built-in redis subchart, this will be automatically set to the redis subchart's username value |
| backgroundServices.nodeSelector | object | `{}` | node labels for background-services pod assignment |
| backgroundServices.podAnnotations | object | `{}` | extra annotations for background-services pod |
| backgroundServices.podLabels | object | `{}` | extra labels for background-services pod |
| backgroundServices.podSecurityContext.fsGroup | int | `1001` | set background-services pod's security context fsGroup |
| backgroundServices.podSecurityContext.runAsNonRoot | bool | `true` | set background-services pod's security context runAsNonRoot |
| backgroundServices.podSecurityContext.runAsUser | int | `1001` | set background-services pod's security context runAsUser |
| backgroundServices.priorityClassName | string | `""` | priority class name to use for the background-services pods; if the priority class is empty or doesn't exist, the background-services pods are scheduled without a priority class |
| backgroundServices.replicaCount | int | `1` | number of background-services replicas to deploy |
| backgroundServices.resources.limits | object | `{"cpu":"1","memory":"1Gi"}` | the requested limits for the background-services container |
| backgroundServices.resources.requests | object | `{"cpu":"500m","memory":"512Mi"}` | the requested resources for the background-services container |
| backgroundServices.revisionHistoryLimit | int | `10` | the number of old ReplicaSets to retain to allow rollback |
| backgroundServices.runAsSeparateDeployment | bool | `false` |  |
| backgroundServices.serviceAccount.annotations | object | `{}` | additional service account annotations (evaluated as a template) |
| backgroundServices.serviceAccount.automountServiceAccountToken | bool | `true` | whether the created service account allows automounting of its API token |
| backgroundServices.serviceAccount.create | bool | `true` | specifies whether a service account should be created |
| backgroundServices.serviceAccount.name | string | `""` | the name of the service account to use. if not set and create is true, a name is generated using the common.names.fullname template with "-background-services" appended |
| backgroundServices.terminationGracePeriodSeconds | string | `nil` | duration in seconds the background-services pod needs to terminate gracefully. Increase if background services need more time to finish in-flight work or close connections to backing services (e.g. Redis, Postgres) before SIGKILL. Leave null to use Kubernetes' default (30s). |
| backgroundServices.tolerations | list | `[]` | tolerations for background-services pod assignment |
| commonAnnotations | object | `{}` | annotations to add to all deployed objects |
| commonLabels | object | `{}` | labels to add to all deployed objects |
| externalDatabase.connectionString | string | `""` | literal database connection URL. Takes precedence over component settings |
| externalDatabase.connectionStringSecretKey | string | `""` | key in `externalDatabase.existingSecret` containing the full database connection URL |
| externalDatabase.driver | string | `""` | database driver used when composing a connection URL from components (e.g. `postgresql+asyncpg`) |
| externalDatabase.driverSecretKey | string | `""` | key in `externalDatabase.existingSecret` containing the database driver |
| externalDatabase.existingSecret | string | `""` | name of an existing Secret to read database settings from |
| externalDatabase.host | string | `""` | database host used when composing a connection URL from components |
| externalDatabase.hostSecretKey | string | `""` | key in `externalDatabase.existingSecret` containing the database host |
| externalDatabase.name | string | `""` | database name used when composing a connection URL from components |
| externalDatabase.nameSecretKey | string | `""` | key in `externalDatabase.existingSecret` containing the database name |
| externalDatabase.password | string | `""` | database password used when composing a connection URL from components |
| externalDatabase.passwordSecretKey | string | `""` | key in `externalDatabase.existingSecret` containing the database password |
| externalDatabase.port | string | `""` | database port used when composing a connection URL from components (e.g. `5432`) |
| externalDatabase.portSecretKey | string | `""` | key in `externalDatabase.existingSecret` containing the database port |
| externalDatabase.username | string | `""` | database username used when composing a connection URL from components |
| externalDatabase.usernameSecretKey | string | `""` | key in `externalDatabase.existingSecret` containing the database username |
| fullnameOverride | string | `"prefect-server"` | fully override common.names.fullname |
| gateway.annotations | object | `{}` | additional annotations for the Gateway resource |
| gateway.className | string | `""` | GatewayClass that will be used to implement the Gateway This must match an existing GatewayClass in your cluster |
| gateway.create | bool | `true` | whether to create a Gateway resource or just the associated HTTPRoute (if enabled) Can be disabled if you want to create the Gateway manually (or is already present) and just have the chart create the HTTPRoute with the correct parentRefs |
| gateway.enabled | bool | `false` | enable Gateway API resources (mutually exclusive with ingress) |
| gateway.infrastructure | object | `{}` | infrastructure configuration for Gateway ref: https://gateway-api.sigs.k8s.io/guides/infrastructure/ |
| gateway.labels | object | `{}` | additional labels for the Gateway resource |
| gateway.listeners | list | `[{"hostname":"","name":"http","port":80,"protocol":"HTTP"},{"hostname":"","name":"https","port":443,"protocol":"HTTPS","tls":{"certificateRefs":[{"kind":"Secret","name":"","namespace":""}],"mode":"Terminate"}}]` | Gateway listeners configuration |
| gateway.listeners[0] | object | `{"hostname":"","name":"http","port":80,"protocol":"HTTP"}` | listener name |
| gateway.listeners[0].hostname | string | `""` | hostname pattern for this listener (e.g., "*.example.com") |
| gateway.listeners[0].port | int | `80` | listener port |
| gateway.listeners[0].protocol | string | `"HTTP"` | listener protocol (HTTP, HTTPS, TCP, TLS) |
| gateway.listeners[1].hostname | string | `""` | hostname pattern for this listener |
| gateway.listeners[1].port | int | `443` | listener port |
| gateway.listeners[1].protocol | string | `"HTTPS"` | listener protocol |
| gateway.listeners[1].tls | object | `{"certificateRefs":[{"kind":"Secret","name":"","namespace":""}],"mode":"Terminate"}` | TLS configuration for HTTPS listener |
| gateway.listeners[1].tls.certificateRefs | list | `[{"kind":"Secret","name":"","namespace":""}]` | certificate references (Secrets containing TLS cert/key) |
| gateway.listeners[1].tls.certificateRefs[0] | object | `{"kind":"Secret","name":"","namespace":""}` | kind of resource (usually Secret) |
| gateway.listeners[1].tls.certificateRefs[0].name | string | `""` | name of the Secret (defaults to ingress pattern if not set) |
| gateway.listeners[1].tls.certificateRefs[0].namespace | string | `""` | namespace of the Secret (optional, defaults to same namespace) |
| gateway.listeners[1].tls.mode | string | `"Terminate"` | TLS mode (Terminate or Passthrough) |
| gateway.name | string | `""` | Gateway resource name (defaults to chart fullname if not set) |
| global.prefect.env | list | `[]` | array with environment variables to add to all deployments |
| global.prefect.image.prefectTag | string | `"3-latest"` | prefect image tag (immutable tags are recommended) |
| global.prefect.image.pullPolicy | string | `"IfNotPresent"` | prefect image pull policy |
| global.prefect.image.pullSecrets | list | `[]` | prefect image pull secrets |
| global.prefect.image.repository | string | `"prefecthq/prefect"` | prefect image repository |
| httproute.annotations | object | `{}` | additional annotations for the HTTPRoute resource |
| httproute.enabled | bool | `true` | enable HTTPRoute resource (mutually exclusive with ingress, auto-enabled when gateway.enabled=true) Can be disabled if you want to create HTTPRoutes manually |
| httproute.extraRules | list | `[]` | additional HTTPRoute rules (advanced usage) Will be merged with auto-generated rules |
| httproute.hostnames | list | `[]` | hostnames that this HTTPRoute should match |
| httproute.labels | object | `{}` | additional labels for the HTTPRoute resource |
| httproute.name | string | `""` | HTTPRoute resource name (defaults to chart fullname if not set) |
| httproute.parentRefs | list | `[{"name":"","namespace":"","port":null,"sectionName":"https"}]` | parent Gateway references |
| httproute.parentRefs[0] | object | `{"name":"","namespace":"","port":null,"sectionName":"https"}` | name of the Gateway to attach to (defaults to gateway.name) |
| httproute.parentRefs[0].namespace | string | `""` | namespace of the Gateway (optional) |
| httproute.parentRefs[0].port | string | `nil` | port number (optional) |
| httproute.parentRefs[0].sectionName | string | `"https"` | specific listener name to attach to (optional, defaults to "https") |
| httproute.path | string | `"/"` | path prefix for HTTPRoute matching |
| httproute.tls | object | `{"redirect":false,"redirectPort":443}` | TLS redirect configuration |
| httproute.tls.redirect | bool | `false` | enable automatic HTTP to HTTPS redirect |
| httproute.tls.redirectPort | int | `443` | HTTPS port for redirect (defaults to 443) |
| ingress.annotations | object | `{}` | additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations. |
| ingress.className | string | `""` | IngressClass that will be used to implement the Ingress (Kubernetes 1.18+) |
| ingress.enabled | bool | `false` | enable ingress record generation for server |
| ingress.extraHosts | list | `[]` | an array with additional hostname(s) to be covered with the ingress record |
| ingress.extraPaths | list | `[]` | an array with additional arbitrary paths that may need to be added to the ingress under the main host |
| ingress.extraRules | list | `[]` | additional rules to be covered with this ingress record |
| ingress.extraTls | list | `[]` | an array with additional tls configuration to be added to the ingress record |
| ingress.host.hostname | string | `"prefect.local"` | default host for the ingress record |
| ingress.host.path | string | `"/"` | default path for the ingress record |
| ingress.host.pathType | string | `"ImplementationSpecific"` | ingress path type |
| ingress.selfSigned | bool | `false` | create a TLS secret for this ingress record using self-signed certificates generated by Helm |
| ingress.servicePort | string | `"server-svc-port"` | port for the ingress' main path |
| ingress.tls | bool | `false` | enable TLS configuration for the host defined at `ingress.host.hostname` parameter |
| migrations.affinity | object | `{}` | affinity for migration job pods assignment |
| migrations.backoffLimit | int | `5` | job backoff limit (number of retries) |
| migrations.command | string | `"prefect server database upgrade -y\n"` | commands to run for database migrations (default: prefect server database upgrade -y) |
| migrations.enabled | bool | `true` | enable the migration Job during chart upgrades (only applies when backgroundServices.runAsSeparateDeployment is true) |
| migrations.entrypoint | list | `["/bin/sh","-c"]` | custom container entrypoint for the migration job |
| migrations.env | list | `[]` | additional environment variables for the migration job; takes precedence over entries of the same name in `global.prefect.env` and `server.env` |
| migrations.extraVolumeMounts | list | `[]` | additional volume mounts for the migration job |
| migrations.extraVolumes | list | `[]` | additional volumes for the migration job |
| migrations.nodeSelector | object | `{}` | node labels for migration job pods assignment |
| migrations.podSecurityContext.fsGroup | int | `1001` | set migration job's pod security context fsGroup |
| migrations.podSecurityContext.runAsNonRoot | bool | `true` | set migration job's pod security context runAsNonRoot |
| migrations.podSecurityContext.runAsUser | int | `1001` | set migration job's pod security context runAsUser |
| migrations.resources | object | `{"limits":{"cpu":"500m","memory":"256Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | job resources configuration |
| migrations.restartPolicy | string | `"Never"` | job restart policy |
| migrations.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1001}` | job security context configuration |
| migrations.timeoutSeconds | int | `300` | job timeout in seconds (default: 300 seconds / 5 minutes) |
| migrations.tolerations | list | `[]` | tolerations for migration job pods assignment |
| nameOverride | string | `""` | partially overrides common.names.name |
| namespaceOverride | string | `""` | fully override common.names.namespace |
| postgresql.auth.database | string | `"server"` | name for a custom database |
| postgresql.auth.enablePostgresUser | bool | `false` | determines whether an admin user is created within postgres |
| postgresql.auth.password | string | `"prefect-rocks"` | password for the custom user. Ignored if `auth.existingSecret` with key `password` is provided |
| postgresql.auth.username | string | `"prefect"` | name for a custom user |
| postgresql.enabled | bool | `true` | enable use of bitnami/postgresql subchart |
| postgresql.image.repository | string | `"bitnamilegacy/postgresql"` | Image repository.  Defaults to legacy bitnami repository for postgres 14.13.0 availability. |
| postgresql.image.tag | string | `"14.13.0"` | Version tag, corresponds to tags at https://hub.docker.com/layers/bitnamilegacy/postgresql/ |
| postgresql.primary.initdb.user | string | `"postgres"` | specify the PostgreSQL username to execute the initdb scripts |
| postgresql.primary.persistence.enabled | bool | `false` | enable PostgreSQL Primary data persistence using PVC |
| redis.architecture | string | `"standalone"` | Redis architecture Note: Prefect currently only supports standalone Redis deployments. |
| redis.enabled | bool | `false` | enable use of bitnami/redis subchart if backgroundServices.runAsSeparateDeployment=true, you must set this to true or provide your own redis instance |
| redis.image.repository | string | `"bitnamilegacy/redis"` | Image repository.  Defaults to legacy bitnami repository for redis 8.2.1 availability. |
| redis.image.tag | string | `"8.2.1"` | Version tag, corresponds to tags at https://hub.docker.com/r/bitnami/redis/ |
| secret.create | bool | `true` | whether to create a Secret containing the PostgreSQL connection string |
| secret.database | string | `""` | database for the PostgreSQL connection string |
| secret.host | string | `""` | host for the PostgreSQL connection string |
| secret.name | string | `""` | name for the Secret containing the PostgreSQL connection string To provide an existing Secret, provide a name and set `create=false` |
| secret.password | string | `""` | password for the PostgreSQL connection string |
| secret.port | string | `""` | port for the PostgreSQL connection string |
| secret.username | string | `""` | username for the PostgreSQL connection string |
| server.affinity | object | `{}` | affinity for server pods assignment |
| server.apiBasePath | string | `"/api"` | sets PREFECT_SERVER_API_BASE_PATH |
| server.args | list | `[]` | Custom container command arguments |
| server.automountServiceAccountToken | bool | `true` | whether the server pod mounts a service account API token. the server does not call the kubernetes api, so this can be set to false |
| server.autoscaling.enabled | bool | `false` | enable autoscaling for server |
| server.autoscaling.maxReplicas | int | `100` | maximum number of server replicas |
| server.autoscaling.minReplicas | int | `1` | minimum number of server replicas |
| server.autoscaling.targetCPU | int | `80` | target CPU utilization percentage |
| server.autoscaling.targetMemory | int | `80` | target Memory utilization percentage |
| server.basicAuth.authString | string | `"admin:pass"` | basic auth credentials in the format admin:<your-password> (no brackets) |
| server.basicAuth.enabled | bool | `false` | enable basic auth for the server, for an administrator/password combination |
| server.basicAuth.existingSecret | string | `""` | name of existing secret containing basic auth credentials. takes precedence over authString. must contain a key `auth-string` with the value of the auth string |
| server.command | list | `[]` | Custom container entrypoint |
| server.containerSecurityContext.allowPrivilegeEscalation | bool | `false` | set server containers' security context allowPrivilegeEscalation |
| server.containerSecurityContext.capabilities | object | `{}` | set server container's security context capabilities |
| server.containerSecurityContext.readOnlyRootFilesystem | bool | `true` | set server containers' security context readOnlyRootFilesystem |
| server.containerSecurityContext.runAsNonRoot | bool | `true` | set server containers' security context runAsNonRoot |
| server.containerSecurityContext.runAsUser | int | `1001` | set server containers' security context runAsUser |
| server.debug | bool | `false` | sets PREFECT_DEBUG_MODE |
| server.env | list | `[]` | array with environment variables to add to server deployment |
| server.extraArgs | list | `[]` | array with extra Arguments for the server container to start with |
| server.extraContainers | list | `[]` | additional sidecar containers |
| server.extraEnvVarsCM | string | `""` | name of existing ConfigMap containing extra env vars to add to server nodes |
| server.extraEnvVarsSecret | string | `""` | name of existing Secret containing extra env vars to add to server nodes |
| server.extraInitContainers | list | `[]` | additional init containers for the server pod. Set `restartPolicy: Always` on an entry to use the native sidecar pattern (Kubernetes 1.29+), which guarantees the sidecar starts before, and is terminated after, the main container — useful for connection proxies (e.g. redis-iam-proxy, cloud-sql-proxy) so the main container can drain its connections cleanly during shutdown. |
| server.extraVolumeMounts | list | `[]` | array with extra volumeMounts for the server pod |
| server.extraVolumes | list | `[]` | array with extra volumes for the server pod |
| server.lifecycle | object | `{}` | lifecycle hooks for the server container. A common use case is a `preStop` sleep so the kube-proxy/load-balancer endpoints deregister before the server starts shutting down. |
| server.livenessProbe.config.failureThreshold | int | `3` | The number of consecutive failures allowed before considering the probe as failed. |
| server.livenessProbe.config.initialDelaySeconds | int | `10` | The number of seconds to wait before starting the first probe. |
| server.livenessProbe.config.periodSeconds | int | `10` | The number of seconds to wait between consecutive probes. |
| server.livenessProbe.config.successThreshold | int | `1` | The minimum consecutive successes required to consider the probe successful. |
| server.livenessProbe.config.timeoutSeconds | int | `5` | The number of seconds to wait for a probe response before considering it as failed. |
| server.livenessProbe.enabled | bool | `true` | enable the server liveness probe |
| server.livenessProbe.path | string | `"{{ .Values.server.apiBasePath }}/health"` | HTTP path for the server liveness probe. |
| server.loggingLevel | string | `"WARNING"` | sets PREFECT_LOGGING_SERVER_LEVEL |
| server.nodeSelector | object | `{}` | node labels for server pods assignment |
| server.podAnnotations | object | `{}` | extra annotations for server pod |
| server.podLabels | object | `{}` | extra labels for server pod |
| server.podSecurityContext.fsGroup | int | `1001` | set server pod's security context fsGroup |
| server.podSecurityContext.runAsNonRoot | bool | `true` | set server pod's security context runAsNonRoot |
| server.podSecurityContext.runAsUser | int | `1001` | set server pod's security context runAsUser |
| server.podSecurityContext.seccompProfile | object | `{"type":"RuntimeDefault"}` | set server pod's seccomp profile |
| server.priorityClassName | string | `""` | priority class name to use for the server pods; if the priority class is empty or doesn't exist, the server pods are scheduled without a priority class |
| server.readinessProbe.config.failureThreshold | int | `3` | The number of consecutive failures allowed before considering the probe as failed. |
| server.readinessProbe.config.initialDelaySeconds | int | `10` | The number of seconds to wait before starting the first probe. |
| server.readinessProbe.config.periodSeconds | int | `10` | The number of seconds to wait between consecutive probes. |
| server.readinessProbe.config.successThreshold | int | `1` | The minimum consecutive successes required to consider the probe successful. |
| server.readinessProbe.config.timeoutSeconds | int | `5` | The number of seconds to wait for a probe response before considering it as failed. |
| server.readinessProbe.enabled | bool | `true` | enable the server readiness probe |
| server.readinessProbe.path | string | `"{{ .Values.server.apiBasePath }}/ready"` | HTTP path for the server readiness probe. |
| server.replicaCount | int | `1` | number of server replicas to deploy, ignored if autoscaling is enabled |
| server.resources.limits | object | `{"cpu":"1","memory":"1Gi"}` | the requested limits for the server container |
| server.resources.requests | object | `{"cpu":"500m","memory":"512Mi"}` | the requested resources for the server container |
| server.revisionHistoryLimit | int | `10` | the number of old ReplicaSets to retain to allow rollback |
| server.startupProbe.config.failureThreshold | int | `30` | The number of consecutive failures allowed before considering the probe as failed. |
| server.startupProbe.config.initialDelaySeconds | int | `0` | The number of seconds to wait before starting the first probe. |
| server.startupProbe.config.periodSeconds | int | `10` | The number of seconds to wait between consecutive probes. |
| server.startupProbe.config.successThreshold | int | `1` | The minimum consecutive successes required to consider the probe successful. |
| server.startupProbe.config.timeoutSeconds | int | `5` | The number of seconds to wait for a probe response before considering it as failed. |
| server.startupProbe.enabled | bool | `true` | enable the server startup probe |
| server.terminationGracePeriodSeconds | string | `nil` | duration in seconds the server pod needs to terminate gracefully. Increase if Prefect needs more time to drain in-flight requests or close connections to backing services (e.g. Redis, Postgres) before SIGKILL. Leave null to use Kubernetes' default (30s). |
| server.tolerations | list | `[]` | tolerations for server pods assignment |
| server.uiConfig.prefectUiApiUrl | string | `"http://localhost:4200/api"` | sets PREFECT_UI_API_URL; supports Helm template expressions such as `{{ .Release.Name }}`. If you want to connect to the UI from somewhere external to the cluster (i.e. via an ingress), you need to set this value to the ingress URL (e.g. http://app.internal.prefect.com/api). You can find additional documentation on this here - https://docs.prefect.io/v3/manage/self-host#ui |
| server.uiConfig.prefectUiStaticDirectory | string | `"/ui_build"` | sets PREFECT_UI_STATIC_DIRECTORY |
| server.updateStrategy | object | `{"type":"RollingUpdate"}` | Specifies the strategy used to replace old Pods by new ones. Type can be "Recreate" or "RollingUpdate". Setting this to "Recreate" is useful when database is on a mounted volume that can only be attached to a single node at a time. |
| service.annotations | object | `{}` | additional custom annotations for server service |
| service.appProtocol | string | `""` | application protocol of the port (e.g. "http") |
| service.clusterIP | string | `""` | service Cluster IP |
| service.externalTrafficPolicy | string | `"Cluster"` | service external traffic policy |
| service.extraPorts | list | `[]` |  |
| service.ipFamilies | list | `[]` | list of IP families (e.g. [IPv4], [IPv6], [IPv4, IPv6]) |
| service.ipFamilyPolicy | string | `""` | service IP family policy for dual-stack support (SingleStack, PreferDualStack, RequireDualStack) ref: https://kubernetes.io/docs/concepts/services-networking/dual-stack/ |
| service.nodePort | string | `""` | service port if defining service as type nodeport |
| service.port | int | `4200` | service port |
| service.portName | string | `"server-svc-port"` | service port name |
| service.targetPort | int | `4200` | target port of the server pod; also sets PREFECT_SERVER_API_PORT |
| service.type | string | `"ClusterIP"` | service type |
| serviceAccount.annotations | object | `{}` | additional service account annotations (evaluated as a template) |
| serviceAccount.automountServiceAccountToken | bool | `true` | whether the created service account allows automounting of its API token |
| serviceAccount.create | bool | `true` | specifies whether a service account should be created |
| serviceAccount.name | string | `""` | the name of the service account to use. if not set and create is true, a name is generated using the common.names.fullname template |
| sqlite.enabled | bool | `false` | enable use of the embedded SQLite database |
| sqlite.persistence.enabled | bool | `true` | enable SQLite data persistence using PVC |
| sqlite.persistence.size | string | `"1Gi"` | size for the PVC |
| sqlite.persistence.storageClassName | string | `""` | storage class name for the PVC |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
