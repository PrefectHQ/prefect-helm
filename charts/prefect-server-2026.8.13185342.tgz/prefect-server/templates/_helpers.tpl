{{/*
Create the name of the service account to associate with the server deployment
*/}}
{{- define "server.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to associate with the background-services deployment
*/}}
{{- define "backgroundServices.serviceAccountName" -}}
{{- if and .Values.backgroundServices.serviceAccount.create .Values.backgroundServices.runAsSeparateDeployment -}}
    {{ .Values.backgroundServices.serviceAccount.name | default (printf "%s-background-services" (include "common.names.fullname" .)) }}
{{- else -}}
    {{ default "default" .Values.backgroundServices.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{- /*
    Reusable block for background services environment variables.
*/ -}}
{{- define "backgroundServices.envVars" -}}
{{- /*
Make redis subchart context available as a variable in this block
*/ -}}
{{- $redis := dict
      "Release"      .Release
      "Capabilities" .Capabilities
      "Values"       .Values.redis
      "Chart"        (dict "Name" "redis")
-}}
- name: PREFECT_SERVER_DATABASE_MIGRATE_ON_START
  value: "false"
- name: PREFECT_MESSAGING_BROKER
  value: {{ .Values.backgroundServices.messaging.broker }}
- name: PREFECT_MESSAGING_CACHE
  value: {{ .Values.backgroundServices.messaging.cache }}
{{- if eq .Values.backgroundServices.messaging.broker "prefect_redis.messaging" }}
- name: PREFECT_SERVER_EVENTS_CAUSAL_ORDERING
  value: prefect_redis.ordering
- name: PREFECT_SERVER_CONCURRENCY_LEASE_STORAGE
  value: prefect_redis.lease_storage
- name: PREFECT_REDIS_MESSAGING_HOST
{{- if and (.Values.redis.enabled) (.Values.backgroundServices.messaging.redis.host | empty) }}
  value: {{ printf "%s-headless" (include "common.names.fullname" $redis) }}.{{ .Release.Namespace }}.svc.cluster.local
{{- else }}
  value: {{ .Values.backgroundServices.messaging.redis.host | quote }}
{{- end }}
- name: PREFECT_REDIS_MESSAGING_PORT
  value: {{ .Values.backgroundServices.messaging.redis.port | quote }}
{{- if (.Values.backgroundServices.messaging.redis.ssl) }}
- name: PREFECT_REDIS_MESSAGING_SSL
  value: {{ .Values.backgroundServices.messaging.redis.ssl | quote }}
{{- end }}
- name: PREFECT_REDIS_MESSAGING_DB
  value: {{ .Values.backgroundServices.messaging.redis.db | quote }}
{{- if not (.Values.backgroundServices.messaging.redis.username | empty) }}
- name: PREFECT_REDIS_MESSAGING_USERNAME
  value: {{ .Values.backgroundServices.messaging.redis.username | quote }}
{{- end -}}
{{- /*
There are four scenarios for passwords:
    1. If the subchart is enabled, reference the secret from the subchart.
       Setting backgroundServices.messaging.redis.password has no effect here.
    2. If an existingSecret is provided, reference that secret with the specified key.
    3. If the subchart is not enabled, use the password defined in the values file.
    4. No password is set, so the environment variable is not defined.
*/ -}}
{{- if and (.Values.redis.enabled) (.Values.backgroundServices.messaging.redis.password | empty) }}
- name: PREFECT_REDIS_MESSAGING_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "common.names.fullname" $redis }}
      key: redis-password
{{- else if not (.Values.backgroundServices.messaging.redis.existingSecret | empty) }}
- name: PREFECT_REDIS_MESSAGING_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.backgroundServices.messaging.redis.existingSecret }}
      key: {{ .Values.backgroundServices.messaging.redis.existingSecretPasswordKey | default "redis-password" }}
{{- else if not (.Values.backgroundServices.messaging.redis.password | empty) }}
- name: PREFECT_REDIS_MESSAGING_PASSWORD
  value: {{ .Values.backgroundServices.messaging.redis.password | quote }}
{{- end }}
{{- end }}
{{- /*
Docket URL for background service coordination (scheduler, late runs, automations).
Priority:
    1. existingSecret - reference a Kubernetes secret containing the full URL.
    2. url - use the plain-text URL from values.
    3. Not set - Docket defaults to memory:// (single-server only).
*/ -}}
{{- if not (.Values.backgroundServices.messaging.docket.existingSecret | empty) }}
- name: PREFECT_SERVER_DOCKET_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.backgroundServices.messaging.docket.existingSecret }}
      key: {{ .Values.backgroundServices.messaging.docket.existingSecretKey | default "docket-url" }}
{{- else if not (.Values.backgroundServices.messaging.docket.url | empty) }}
- name: PREFECT_SERVER_DOCKET_URL
  value: {{ .Values.backgroundServices.messaging.docket.url | quote }}
{{- end }}
{{- end -}}

{{- /*
    server.migrations.envVars:
      Merged env vars for the migrations Job, deduplicated by name so the
      same variable is never emitted twice in the Job spec.

      Precedence (highest wins):
        1. .Values.migrations.env
        2. .Values.server.env
        3. .Values.global.prefect.env

      Iterates highest-precedence first and appends each entry only if its
      name has not yet been seen, so the emitted list has unique names with
      the highest-precedence value for each. Order within the output is
      highest-precedence source first, which is semantically equivalent in
      Kubernetes (env order does not affect resolution).
*/ -}}
{{- define "server.migrations.envVars" -}}
{{- $sources := list .Values.migrations.env .Values.server.env .Values.global.prefect.env -}}
{{- $seen := dict -}}
{{- $merged := list -}}
{{- range $source := $sources -}}
  {{- range $entry := $source -}}
    {{- if not (hasKey $seen $entry.name) -}}
      {{- $_ := set $seen $entry.name true -}}
      {{- $merged = append $merged $entry -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if $merged -}}
{{- include "common.tplvalues.render" (dict "value" $merged "context" $) }}
{{- end -}}
{{- end -}}

{{/* ----- Connection string templates ------ */}}

{{/*
  server.postgres-hostname:
    Generate the hostname of the postgresql service
    If a subchart is used, evaluate using its fullname function
		  and append the namespace at the end.
    Otherwise, the configured external hostname will be returned
*/}}
{{- define "server.postgres-hostname" -}}
{{- if .Values.postgresql.enabled -}}
{{-   $subchart_overrides := .Values.postgresql -}}
{{-   $name := include "postgresql.v1.primary.fullname" (dict "Values" $subchart_overrides "Chart" (dict "Name" "postgresql") "Release" .Release) -}}
{{-   printf "%s.%s" $name .Release.Namespace -}}
{{- else -}}
{{-   .Values.secret.host | required ".Values.secret.host is required." -}}
{{- end -}}
{{- end -}}

{{/*
  server.postgres-port:
    Generate the port of the postgresql service
    If a subchart is used, evaluate using its port function
    Otherwise, the configured port will be returned
*/}}
{{- define "server.postgres-port" -}}
{{- if .Values.postgresql.enabled -}}
{{-   $subchart_overrides := .Values.postgresql -}}
{{-   include "postgresql.v1.service.port" (dict "Values" $subchart_overrides) -}}
{{- else -}}
{{-   .Values.secret.port | required ".Values.secret.port is required." -}}
{{- end -}}
{{- end -}}

{{/*
  server.postgres-username:
    Generate the username for postgresql
    If a subchart is used, evaluate using its username function
    Otherwise, the configured username will be returned
*/}}
{{- define "server.postgres-username" -}}
{{- if .Values.postgresql.enabled -}}
{{-   $subchart_overrides := .Values.postgresql -}}
{{-   include "postgresql.v1.username" (dict "Values" $subchart_overrides) -}}
{{- else -}}
{{-   .Values.secret.username | required ".Values.secret.username is required." -}}
{{- end -}}
{{- end -}}

{{/*
  server.postgres-password:
    Generate the password for postgresql
    If a subchart is used, evaluate using its password value
    Otherwise, the configured password will be returned
*/}}
{{- define "server.postgres-password" -}}
{{- if .Values.postgresql.enabled -}}
{{-   .Values.postgresql.auth.password | required ".Values.postgresql.auth.password is required." -}}
{{- else -}}
{{-   .Values.secret.password | required ".Values.secret.password is required." -}}
{{- end -}}
{{- end -}}

{{/*
  server.postgres-database:
    Generate the database for postgresql
    If a subchart is used, evaluate using its database value
    Otherwise, the configured database will be returned
*/}}
{{- define "server.postgres-database" -}}
{{- if .Values.postgresql.enabled -}}
{{-   .Values.postgresql.auth.database | required ".Values.postgresql.auth.database is required." -}}
{{- else -}}
{{-   .Values.secret.database | required ".Values.secret.database is required." -}}
{{- end -}}
{{- end -}}

{{/*
  server.postgres-connstr:
    Generates the connection string for the postgresql service
*/}}
{{- define "server.postgres-connstr" -}}
{{- $user := include "server.postgres-username" . -}}
{{- $pass := include "server.postgres-password" . -}}
{{- $host := include "server.postgres-hostname" . -}}
{{- $port := include "server.postgres-port" . -}}
{{- $db := include "server.postgres-database" . -}}
{{- printf "postgresql+asyncpg://%s:%s@%s:%s/%s" $user $pass $host $port $db -}}
{{- end -}}

{{/*
  server.postgres-string-secret-name:
    Get the name of the secret to be used for the postgresql
    user password. Generates {release-name}-postgresql-connection if
    an existing secret is not set.
*/}}
{{- define "server.postgres-string-secret-name" -}}
{{- if .Values.postgresql.auth.existingSecret -}}
  {{- .Values.postgresql.auth.existingSecret -}}
{{- else if .Values.secret.name -}}
  {{- .Values.secret.name -}}
{{- else -}}
  {{- $name := include "common.names.fullname" . -}}
  {{- printf "%s-%s" $name "postgresql-connection" -}}
{{- end -}}
{{- end -}}

{{/*
  server.database-has-component-config:
    Returns true when the new database component configuration is in use.
*/}}
{{- define "server.database-has-component-config" -}}
{{- $db := .Values.externalDatabase | default dict -}}
{{- if or $db.driver $db.driverSecretKey $db.username $db.usernameSecretKey $db.password $db.passwordSecretKey $db.host $db.hostSecretKey $db.port $db.portSecretKey $db.name $db.nameSecretKey -}}
true
{{- end -}}
{{- end -}}

{{/*
  server.database-secret-name:
    Returns the Secret name for database settings loaded from secret keys.
*/}}
{{- define "server.database-secret-name" -}}
{{- $db := .Values.externalDatabase | default dict -}}
{{- $db.existingSecret | required ".Values.externalDatabase.existingSecret is required when using database secret keys." -}}
{{- end -}}

{{/*
  server.database-env-var:
    Renders one database environment variable from a literal value or a Secret key.
*/}}
{{- define "server.database-env-var" -}}
{{- $ctx := .context -}}
{{- $name := .name -}}
{{- $value := .value -}}
{{- $secretKey := .secretKey -}}
- name: {{ $name }}
  {{- if $secretKey }}
  valueFrom:
    secretKeyRef:
      name: {{ include "server.database-secret-name" $ctx }}
      key: {{ $secretKey }}
  {{- else }}
  value: {{ $value | required (printf ".Values.externalDatabase.%s or .Values.externalDatabase.%sSecretKey is required." .field .field) | toString | quote }}
  {{- end }}
{{- end -}}

{{/*
  server.database-component-ref:
    Returns either the literal component value or a Kubernetes env expansion.
*/}}
{{- define "server.database-component-ref" -}}
{{- if .secretKey -}}
{{- printf "$(%s)" .envName -}}
{{- else -}}
{{- .value | required (printf ".Values.externalDatabase.%s or .Values.externalDatabase.%sSecretKey is required." .field .field) | toString -}}
{{- end -}}
{{- end -}}

{{/*
  server.database-component-env:
    Renders database component env vars and composes the Prefect connection URL.
*/}}
{{- define "server.database-component-env" -}}
{{- $db := .Values.externalDatabase | default dict -}}
{{- $driver := $db.driver | default "postgresql+asyncpg" -}}
{{- $port := $db.port | default "5432" -}}
{{- $driverRef := include "server.database-component-ref" (dict "envName" "PREFECT_SERVER_DATABASE_DRIVER" "field" "driver" "value" $driver "secretKey" $db.driverSecretKey) -}}
{{- $usernameRef := include "server.database-component-ref" (dict "envName" "PREFECT_SERVER_DATABASE_USER" "field" "username" "value" $db.username "secretKey" $db.usernameSecretKey) -}}
{{- $passwordRef := include "server.database-component-ref" (dict "envName" "PREFECT_SERVER_DATABASE_PASSWORD" "field" "password" "value" $db.password "secretKey" $db.passwordSecretKey) -}}
{{- $hostRef := include "server.database-component-ref" (dict "envName" "PREFECT_SERVER_DATABASE_HOST" "field" "host" "value" $db.host "secretKey" $db.hostSecretKey) -}}
{{- $portRef := include "server.database-component-ref" (dict "envName" "PREFECT_SERVER_DATABASE_PORT" "field" "port" "value" $port "secretKey" $db.portSecretKey) -}}
{{- $nameRef := include "server.database-component-ref" (dict "envName" "PREFECT_SERVER_DATABASE_NAME" "field" "name" "value" $db.name "secretKey" $db.nameSecretKey) -}}
{{- include "server.database-env-var" (dict "context" . "name" "PREFECT_SERVER_DATABASE_DRIVER" "field" "driver" "value" $driver "secretKey" $db.driverSecretKey) }}
{{ include "server.database-env-var" (dict "context" . "name" "PREFECT_SERVER_DATABASE_USER" "field" "username" "value" $db.username "secretKey" $db.usernameSecretKey) }}
{{ include "server.database-env-var" (dict "context" . "name" "PREFECT_SERVER_DATABASE_PASSWORD" "field" "password" "value" $db.password "secretKey" $db.passwordSecretKey) }}
{{ include "server.database-env-var" (dict "context" . "name" "PREFECT_SERVER_DATABASE_HOST" "field" "host" "value" $db.host "secretKey" $db.hostSecretKey) }}
{{ include "server.database-env-var" (dict "context" . "name" "PREFECT_SERVER_DATABASE_PORT" "field" "port" "value" $port "secretKey" $db.portSecretKey) }}
{{ include "server.database-env-var" (dict "context" . "name" "PREFECT_SERVER_DATABASE_NAME" "field" "name" "value" $db.name "secretKey" $db.nameSecretKey) }}
- name: PREFECT_SERVER_DATABASE_CONNECTION_URL
  value: {{ printf "%s://%s:%s@%s:%s/%s" $driverRef $usernameRef $passwordRef $hostRef $portRef $nameRef | quote }}
{{- end -}}

{{/*
  server.database-env:
    Renders database env vars for server, background services, and migrations.
*/}}
{{- define "server.database-env" -}}
{{- $db := .Values.externalDatabase | default dict -}}
{{- if .Values.sqlite.enabled }}
- name: PREFECT_SERVER_DATABASE_CONNECTION_URL
  value: "sqlite+aiosqlite:////data/prefect.db"
{{- else if $db.connectionString }}
- name: PREFECT_SERVER_DATABASE_CONNECTION_URL
  value: {{ $db.connectionString | quote }}
{{- else if $db.connectionStringSecretKey }}
- name: PREFECT_SERVER_DATABASE_CONNECTION_URL
  valueFrom:
    secretKeyRef:
      name: {{ include "server.database-secret-name" . }}
      key: {{ $db.connectionStringSecretKey }}
{{- else if include "server.database-has-component-config" . }}
{{- include "server.database-component-env" . }}
{{- else }}
- name: PREFECT_SERVER_DATABASE_CONNECTION_URL
  valueFrom:
    secretKeyRef:
      name: {{ include "server.postgres-string-secret-name" . }}
      key: connection-string
{{- end -}}
{{- end -}}

{{/* ----- End connection string templates ----- */}}

{{- define "server.uiUrl" -}}
  {{- printf "%s" (replace "/api" "" (tpl .Values.server.uiConfig.prefectUiApiUrl .)) -}}
{{- end -}}

{{/* ----- Gateway API Helper Templates ----- */}}

{{/*
  gateway.name:
    Returns the name of the Gateway resource
*/}}
{{- define "gateway.name" -}}
{{- if .Values.gateway.name -}}
  {{- .Values.gateway.name -}}
{{- else -}}
  {{- include "common.names.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
  httproute.name:
    Returns the name of the HTTPRoute resource
*/}}
{{- define "httproute.name" -}}
{{- if .Values.httproute.name -}}
  {{- .Values.httproute.name -}}
{{- else -}}
  {{- include "common.names.fullname" . -}}
{{- end -}}
{{- end -}}

{{/*
  gateway.hostnames:
    Returns the list of hostnames for Gateway/HTTPRoute from httproute.hostnames
*/}}
{{- define "gateway.hostnames" -}}
{{- if .Values.httproute.hostnames -}}
  {{- toYaml .Values.httproute.hostnames -}}
{{- end -}}
{{- end -}}

{{/*
  gateway.tlsSecretName:
    Returns the TLS secret name based on the first gateway hostname or release name
*/}}
{{- define "gateway.tlsSecretName" -}}
{{- $hostnames := include "gateway.hostnames" . | fromYamlArray -}}
{{- if $hostnames -}}
  {{- printf "%s-tls" (index $hostnames 0) -}}
{{- else -}}
  {{- printf "%s-tls" (include "common.names.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
  gateway.apiAvailable:
    Check if Gateway API is available in the cluster
    Returns "true" if available, empty otherwise
*/}}
{{- define "gateway.apiAvailable" -}}
{{- if .Capabilities.APIVersions.Has "gateway.networking.k8s.io/v1/Gateway" -}}
true
{{- end -}}
{{- end -}}

{{/* ----- End Gateway API Helper Templates ----- */}}
